import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Animated, FlatList, Pressable, ScrollView, StyleSheet, Switch, Text,
  TextInput, Vibration, View, Easing,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { C, MODES, GAMES } from './src/theme';
import { SERVERS, REGIONS } from './src/servers';
import * as DnsVpn from './modules/dns-vpn';

const pingColor = (p) => (p < 80 ? C.grn : p < 130 ? '#ffc542' : C.red);

async function realPing() {
  const t = Date.now();
  try { await fetch('https://1.1.1.1/cdn-cgi/trace', { method: 'HEAD' }); return Date.now() - t; }
  catch { return null; }
}

export default function App() {
  const [mode, setMode] = useState('web');
  const [tab, setTab] = useState('all');
  const [sel, setSel] = useState(null); // null = best location
  const [on, setOn] = useState(false);
  const [busy, setBusy] = useState(false);
  const [fav, setFav] = useState({});
  const [q, setQ] = useState('');
  const [live, setLive] = useState(null);
  const [gm, setGm] = useState([true, true, false, false]);
  const [opts, setOpts] = useState([true, true, true]);

  const ac = mode === 'game' ? C.red : C.grn;
  const adj = (s) => s.ping + (mode === 'game' ? -6 : mode === 'web' ? 4 : 0);
  const bestIdx = useMemo(() => SERVERS.reduce((b, s, i) => (adj(s) < adj(SERVERS[b]) ? i : b), 0), [mode]);
  const cur = SERVERS[sel ?? bestIdx];

  // ---- mode switch effect ----
  const flash = useRef(new Animated.Value(0)).current;
  const shake = useRef(new Animated.Value(0)).current;
  const [fxMode, setFxMode] = useState('web');
  const changeMode = (m) => {
    if (m === mode) return;
    if (m === 'auto') { setMode(m); return; }
    setFxMode(m);
    flash.setValue(0);
    Animated.sequence([
      Animated.timing(flash, { toValue: 1, duration: 140, useNativeDriver: true }),
      Animated.delay(m === 'game' ? 520 : 440),
      Animated.timing(flash, { toValue: 0, duration: 300, useNativeDriver: true }),
    ]).start();
    if (m === 'game') {
      Vibration.vibrate([0, 40, 30, 80]);
      shake.setValue(0);
      Animated.sequence([6, -6, 4, -3, 0].map((v) =>
        Animated.timing(shake, { toValue: v, duration: 70, easing: Easing.linear, useNativeDriver: true }))).start();
    }
    setTimeout(() => setMode(m), 220);
  };

  // ---- connect / disconnect ----
  const toggle = async () => {
    if (busy) return;
    if (on) { await DnsVpn.stop(); setOn(false); setLive(null); return; }
    setBusy(true);
    const [d1, d2] = MODES[mode].dns;
    const pkgs = mode === 'game' ? GAMES.filter((_, i) => gm[i]).map((g) => g.pkg) : [];
    let ok = true;
    if (DnsVpn.isAvailable()) ok = await DnsVpn.start(d1, d2, pkgs);
    else await new Promise((r) => setTimeout(r, 1200)); // Expo Go: simulation
    setBusy(false);
    setOn(!!ok);
  };

  useEffect(() => {
    if (!on) return;
    const id = setInterval(async () => {
      const real = DnsVpn.isAvailable() ? await realPing() : null;
      const p = real ?? Math.round(adj(cur) + Math.random() * 8 - 3);
      setLive({ p, j: Math.round(1 + Math.random() * (mode === 'game' ? 2 : 5)), s: mode === 'web' ? 80 + Math.round(Math.random() * 40) : 45 + Math.round(Math.random() * 25) });
    }, 1500);
    return () => clearInterval(id);
  }, [on, mode, sel]);

  // restart with new DNS when mode changes while connected
  useEffect(() => {
    if (on && DnsVpn.isAvailable()) {
      const [d1, d2] = MODES[mode].dns;
      DnsVpn.start(d1, d2, mode === 'game' ? GAMES.filter((_, i) => gm[i]).map((g) => g.pkg) : []);
    }
  }, [mode]);

  const list = useMemo(() => {
    let ids = SERVERS.map((_, i) => i);
    if (tab === 'fav') ids = ids.filter((i) => fav[i]);
    if (tab === 'srch') ids = ids.filter((i) => SERVERS[i].name.toLowerCase().includes(q.toLowerCase()));
    if (tab === 'pin') ids.sort((a, b) => SERVERS[a].region.localeCompare(SERVERS[b].region));
    return ids;
  }, [tab, q, fav]);

  const Row = ({ i }) => {
    const s = SERVERS[i]; const p = adj(s);
    return (
      <Pressable style={[st.row, i === (sel ?? bestIdx) && on && { backgroundColor: ac + '1A' }]} onPress={() => setSel(i)}>
        <Text style={st.flag}>{s.flag}</Text>
        <View style={{ flex: 1 }}>
          <Text style={st.name}>{s.name}</Text>
          <Text style={st.sub}>{REGIONS[s.region]}</Text>
        </View>
        <Text style={{ color: pingColor(p), fontSize: 12 }}>{p} ms</Text>
        <Pressable hitSlop={12} onPress={() => setFav((f) => ({ ...f, [i]: !f[i] }))}>
          <Ionicons name={fav[i] ? 'heart' : 'add'} size={26} color={fav[i] ? C.red : C.mu} />
        </Pressable>
      </Pressable>
    );
  };

  const Tools = () => (
    <ScrollView contentContainerStyle={{ paddingBottom: 160 }}>
      <View style={st.card}>
        <View style={{ flexDirection: 'row', gap: 8 }}>
          {[['پینگ', live ? live.p + ' ms' : '–'], ['جیتر', live ? live.j + ' ms' : '–'], ['سرعت', live ? live.s + ' Mbps' : '–']].map(([k, v]) => (
            <View key={k} style={st.m3}><Text style={st.sub}>{k}</Text><Text style={st.m3v}>{v}</Text></View>
          ))}
        </View>
      </View>
      <View style={st.card}>
        <Text style={st.title}>{mode === 'game' ? '🎮 بازی‌ها' : '🌐 وب‌گردی امن'}</Text>
        {(mode === 'game' ? GAMES.map((g) => g.name) : ['بلاک تبلیغات', 'بلاک ردیاب‌ها', 'سایت‌های مخرب']).map((n, i) => (
          <View key={n} style={st.opt}>
            <Text style={st.name2}>{n}</Text>
            <Switch value={mode === 'game' ? gm[i] : opts[i]} trackColor={{ true: ac, false: C.bd }} thumbColor="#fff"
              onValueChange={(v) => (mode === 'game' ? setGm((a) => a.map((x, k) => (k === i ? v : x))) : setOpts((a) => a.map((x, k) => (k === i ? v : x))))} />
          </View>
        ))}
        <View style={st.opt}><Text style={st.name2}>DNS</Text><Text style={st.sub}>{MODES[mode].dns.join(' · ')}</Text></View>
      </View>
      {!DnsVpn.isAvailable() && <Text style={[st.sub, { margin: 18 }]}>حالت شبیه‌سازی (Expo Go). برای VPN واقعی، Development Build بساز.</Text>}
    </ScrollView>
  );

  const tabs = [['all', 'compass-outline'], ['fav', 'heart-outline'], ['pin', 'location-outline'], ['cmd', 'terminal-outline']];

  return (
    <Animated.View style={[st.root, { transform: [{ translateX: shake }] }]}>
      <StatusBar style="light" />
      <View style={st.hero}>
        <Text style={st.bigFlag}>{cur.flag}</Text>
        <LinearGradient colors={[ac + '30', C.bg]} style={StyleSheet.absoluteFill} />
        <View style={st.top}>
          <Ionicons name="menu" size={30} color="#fff" />
          <Text style={st.logo}>DNS <Text style={{ color: ac }}>SHIELD</Text></Text>
        </View>
        <View style={st.mid}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
            <View style={[st.pill, on && { borderColor: ac }]}><Text style={[st.pillT, on && { color: ac }]}>{on ? 'ON' : busy ? '…' : 'OFF'}</Text></View>
            <Text style={st.proto}>{mode === 'game' ? 'DNS · UDP 53' : 'DNS · Filter'}</Text>
          </View>
          <Pressable onPress={toggle} style={[st.pwr, on && { backgroundColor: ac, shadowColor: ac, shadowOpacity: 0.9, shadowRadius: 24, elevation: 14 }, busy && { opacity: 0.6 }]}>
            <Ionicons name="power" size={50} color="#0b0f1a" />
          </Pressable>
        </View>
        <Text style={st.city}>{cur.name}</Text>
        <View style={st.net}>
          <Ionicons name="wifi" size={22} color="#cfd4e4" />
          <Text style={st.net2}>{mode === 'game' ? 'GAME BOOST' : mode === 'web' ? 'SAFE DNS' : 'AUTO'}</Text>
          {live && <Text style={[st.sub, { marginLeft: 'auto', color: ac }]}>PING {live.p} · ↓ {live.s}</Text>}
        </View>
      </View>

      <View style={st.tabs}>
        {tabs.map(([k, ic]) => (
          <Pressable key={k} onPress={() => setTab(k)} style={[st.tabB, tab === k && { backgroundColor: '#fff' }]}>
            <Ionicons name={ic} size={24} color={tab === k ? '#0b0f1a' : C.mu} />
          </Pressable>
        ))}
        <View style={{ flex: 1 }} />
        <Pressable onPress={() => setTab('srch')} style={[st.tabB, tab === 'srch' && { backgroundColor: '#fff' }]}>
          <Ionicons name="search" size={24} color={tab === 'srch' ? '#0b0f1a' : C.mu} />
        </Pressable>
      </View>
      {tab === 'srch' && <TextInput value={q} onChangeText={setQ} placeholder="جستجوی کشور…" placeholderTextColor={C.mu} style={st.input} />}

      {tab === 'cmd' ? <Tools /> : (
        <FlatList
          data={list}
          keyExtractor={(i) => String(i)}
          contentContainerStyle={{ paddingBottom: 160 }}
          ListHeaderComponent={<>
            <Text style={st.hd}>All locations ({list.length})</Text>
            {tab === 'all' && (
              <Pressable style={st.row} onPress={() => setSel(null)}>
                <Text style={st.flag}>{SERVERS[bestIdx].flag}</Text>
                <View style={{ flex: 1 }}><Text style={st.name}>بهترین مکان</Text><Text style={st.sub}>کم‌پینگ‌ترین سرور خودکار</Text></View>
                <Ionicons name="chevron-forward" size={24} color={C.mu} />
              </Pressable>
            )}
          </>}
          renderItem={({ item }) => <Row i={item} />}
        />
      )}

      <View style={st.dock}>
        <View style={st.dk}>
          {Object.entries(MODES).map(([k, m]) => {
            const active = k === mode; const col = k === 'game' ? C.red : C.grn;
            return (
              <Pressable key={k} onPress={() => changeMode(k)} style={[st.dkB, active && { borderColor: col }]}>
                <Ionicons name={m.icon} size={22} color={active ? col : C.mu} />
                <Text style={[st.dkT, active && { color: col }]}>{m.label}</Text>
              </Pressable>
            );
          })}
        </View>
      </View>

      <Animated.View pointerEvents="none" style={[st.fx, { opacity: flash, backgroundColor: fxMode === 'game' ? 'rgba(120,0,20,0.92)' : 'rgba(0,40,25,0.9)' }]}>
        <Text style={[st.fxT, fxMode === 'game' ? { color: '#fff', textShadowColor: C.red, textShadowOffset: { width: 4, height: 0 }, textShadowRadius: 2 } : { color: C.grn, textShadowColor: C.grn, textShadowRadius: 20 }]}>
          {fxMode === 'game' ? 'GAME MODE' : 'SAFE WEB'}
        </Text>
      </Animated.View>
    </Animated.View>
  );
}

const st = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg },
  hero: { paddingTop: 52, paddingHorizontal: 18, paddingBottom: 16, overflow: 'hidden', borderBottomWidth: 1, borderBottomColor: C.bd },
  bigFlag: { position: 'absolute', fontSize: 230, opacity: 0.2, left: -10, top: 0 },
  top: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  logo: { color: C.tx, fontSize: 22, fontWeight: '800' },
  mid: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 16 },
  pill: { borderWidth: 1.5, borderColor: C.mu, borderRadius: 20, paddingVertical: 5, paddingHorizontal: 12 },
  pillT: { color: C.mu, fontWeight: '800', fontSize: 12 },
  proto: { color: C.tx, fontWeight: '700', fontSize: 16 },
  pwr: { width: 104, height: 104, borderRadius: 52, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  city: { color: C.tx, fontSize: 30, fontWeight: '700', marginTop: 14, marginBottom: 10 },
  net: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  net2: { color: '#cfd4e4', fontSize: 15, fontWeight: '600' },
  tabs: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 18, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: C.bd },
  tabB: { padding: 7, borderRadius: 20 },
  input: { margin: 14, marginBottom: 0, padding: 12, borderRadius: 12, backgroundColor: C.c1, borderWidth: 1, borderColor: C.bd, color: C.tx },
  hd: { color: C.mu, fontSize: 13, paddingHorizontal: 18, paddingTop: 16, paddingBottom: 6 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 16, paddingVertical: 13, paddingHorizontal: 18 },
  flag: { fontSize: 30, width: 38, textAlign: 'center' },
  name: { color: C.tx, fontSize: 20 },
  sub: { color: C.mu, fontSize: 11, marginTop: 2 },
  card: { marginHorizontal: 18, marginTop: 12, backgroundColor: C.c1, borderWidth: 1, borderColor: C.bd, borderRadius: 16, padding: 14 },
  m3: { flex: 1, backgroundColor: C.c2, borderRadius: 12, padding: 10, alignItems: 'center' },
  m3v: { color: C.tx, fontSize: 16, fontWeight: '700', marginTop: 4 },
  title: { color: C.tx, fontWeight: '700', marginBottom: 6 },
  opt: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 8 },
  name2: { color: C.tx, fontSize: 14 },
  dock: { position: 'absolute', bottom: 0, left: 0, right: 0, padding: 14, paddingBottom: 24, backgroundColor: C.bg + 'EE' },
  dk: { flexDirection: 'row', gap: 8, backgroundColor: C.c1, borderWidth: 1, borderColor: C.bd, borderRadius: 20, padding: 8 },
  dkB: { flex: 1, alignItems: 'center', gap: 3, paddingVertical: 10, borderRadius: 14, backgroundColor: C.c2, borderWidth: 1.5, borderColor: 'transparent' },
  dkT: { color: C.mu, fontSize: 13, fontWeight: '700' },
  fx: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center' },
  fxT: { fontSize: 42, fontWeight: '900', letterSpacing: 3 },
});
