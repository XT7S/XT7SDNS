package expo.modules.dnsvpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import expo.modules.kotlin.Promise
import expo.modules.kotlin.exception.Exceptions
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class DnsVpnModule : Module() {
  private val requestCode = 7421
  private var pendingPromise: Promise? = null
  private var pendingIntent: Intent? = null

  override fun definition() = ModuleDefinition {
    Name("DnsVpn")

    AsyncFunction("start") { dns1: String, dns2: String, packages: List<String>, promise: Promise ->
      val ctx = appContext.reactContext ?: throw Exceptions.ReactContextLost()
      val activity = appContext.currentActivity ?: throw Exceptions.MissingActivity()
      val serviceIntent = Intent(ctx, DnsVpnService::class.java).apply {
        putExtra("dns1", dns1)
        putExtra("dns2", dns2)
        putStringArrayListExtra("packages", ArrayList(packages))
      }
      val prepare = VpnService.prepare(ctx)
      if (prepare != null) {
        pendingPromise = promise
        pendingIntent = serviceIntent
        activity.startActivityForResult(prepare, requestCode)
      } else {
        ctx.startService(serviceIntent)
        promise.resolve(true)
      }
    }

    AsyncFunction("stop") {
      val ctx = appContext.reactContext ?: throw Exceptions.ReactContextLost()
      ctx.startService(Intent(ctx, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_STOP))
    }

    Function("isRunning") { DnsVpnService.running }

    OnActivityResult { _, payload ->
      if (payload.requestCode == requestCode) {
        val ctx = appContext.reactContext
        if (payload.resultCode == Activity.RESULT_OK && ctx != null) {
          ctx.startService(pendingIntent)
          pendingPromise?.resolve(true)
        } else {
          pendingPromise?.resolve(false)
        }
        pendingPromise = null
        pendingIntent = null
      }
    }
  }
}
