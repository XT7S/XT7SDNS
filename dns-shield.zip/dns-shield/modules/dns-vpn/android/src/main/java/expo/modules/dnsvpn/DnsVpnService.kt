package expo.modules.dnsvpn

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

/**
 * Local DNS-only VPN: only traffic to the two DNS servers is routed into the TUN.
 * DNS queries are forwarded over a protected socket, so the rest of the traffic
 * keeps using the normal network (no speed loss).
 */
class DnsVpnService : VpnService() {
  companion object {
    @Volatile var running = false
    const val ACTION_STOP = "expo.modules.dnsvpn.STOP"
  }

  private var tun: ParcelFileDescriptor? = null
  private var worker: Thread? = null
  private val pool = Executors.newFixedThreadPool(8)

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (intent?.action == ACTION_STOP) {
      stopVpn()
      return START_NOT_STICKY
    }
    val dns1 = intent?.getStringExtra("dns1") ?: "1.1.1.1"
    val dns2 = intent?.getStringExtra("dns2") ?: "8.8.8.8"
    val pkgs = intent?.getStringArrayListExtra("packages") ?: arrayListOf()
    startVpn(dns1, dns2, pkgs)
    return START_STICKY
  }

  private fun startVpn(dns1: String, dns2: String, pkgs: List<String>) {
    cleanup()
    val b = Builder()
      .setSession("DNS Shield")
      .addAddress("10.111.0.2", 32)
      .addDnsServer(dns1)
      .addDnsServer(dns2)
      .addRoute(dns1, 32)
      .addRoute(dns2, 32)
      .setBlocking(true)
    // Optional per-app mode (empty list = all apps)
    pkgs.forEach { try { b.addAllowedApplication(it) } catch (_: Exception) {} }
    tun = b.establish() ?: return
    running = true
    val fd = tun!!.fileDescriptor
    worker = Thread { loop(FileInputStream(fd), FileOutputStream(fd)) }.also { it.start() }
  }

  private fun loop(input: FileInputStream, out: FileOutputStream) {
    val buf = ByteArray(32767)
    try {
      while (running) {
        val n = input.read(buf)
        if (n <= 0) continue
        if ((buf[0].toInt() shr 4) != 4 || buf[9].toInt() != 17) continue // IPv4 + UDP only
        val ihl = (buf[0].toInt() and 0x0f) * 4
        if (n < ihl + 8) continue
        val srcIp = buf.copyOfRange(12, 16)
        val dstIp = buf.copyOfRange(16, 20)
        val srcPort = ((buf[ihl].toInt() and 0xff) shl 8) or (buf[ihl + 1].toInt() and 0xff)
        val dstPort = ((buf[ihl + 2].toInt() and 0xff) shl 8) or (buf[ihl + 3].toInt() and 0xff)
        if (dstPort != 53) continue
        val payload = buf.copyOfRange(ihl + 8, n)
        pool.execute { forward(payload, srcIp, dstIp, srcPort, out) }
      }
    } catch (_: Exception) {
    } finally {
      running = false
    }
  }

  private fun forward(q: ByteArray, srcIp: ByteArray, dstIp: ByteArray, srcPort: Int, out: FileOutputStream) {
    try {
      val s = DatagramSocket()
      protect(s)
      s.soTimeout = 3000
      s.send(DatagramPacket(q, q.size, InetAddress.getByAddress(dstIp), 53))
      val rb = ByteArray(4096)
      val rp = DatagramPacket(rb, rb.size)
      s.receive(rp)
      s.close()
      val pkt = buildUdp(dstIp, srcIp, 53, srcPort, rb, rp.length)
      synchronized(out) { out.write(pkt) }
    } catch (_: Exception) {
    }
  }

  private fun buildUdp(src: ByteArray, dst: ByteArray, sp: Int, dp: Int, data: ByteArray, n: Int): ByteArray {
    val total = 28 + n
    val p = ByteArray(total)
    p[0] = 0x45
    p[2] = (total shr 8).toByte(); p[3] = total.toByte()
    p[6] = 0x40; p[8] = 64; p[9] = 17
    src.copyInto(p, 12); dst.copyInto(p, 16)
    var sum = 0
    for (i in 0 until 20 step 2) sum += ((p[i].toInt() and 0xff) shl 8) or (p[i + 1].toInt() and 0xff)
    while ((sum shr 16) != 0) sum = (sum and 0xffff) + (sum shr 16)
    val ck = sum.inv() and 0xffff
    p[10] = (ck shr 8).toByte(); p[11] = ck.toByte()
    p[20] = (sp shr 8).toByte(); p[21] = sp.toByte()
    p[22] = (dp shr 8).toByte(); p[23] = dp.toByte()
    val ul = 8 + n
    p[24] = (ul shr 8).toByte(); p[25] = ul.toByte()
    data.copyInto(p, 28, 0, n)
    return p
  }

  private fun cleanup() {
    running = false
    try { tun?.close() } catch (_: Exception) {}
    tun = null
    worker?.interrupt()
    worker = null
  }

  private fun stopVpn() {
    cleanup()
    stopSelf()
  }

  override fun onDestroy() {
    cleanup()
    super.onDestroy()
  }
}
