import { requireNativeModule } from 'expo-modules-core';

let Native = null;
try {
  Native = requireNativeModule('DnsVpn');
} catch (e) {
  Native = null; // Expo Go: UI works in simulation mode
}

export const isAvailable = () => !!Native;
export const start = (dns1, dns2, packages = []) =>
  Native ? Native.start(dns1, dns2, packages) : Promise.resolve(false);
export const stop = () => (Native ? Native.stop() : Promise.resolve());
export const isRunning = () => (Native ? Native.isRunning() : false);
