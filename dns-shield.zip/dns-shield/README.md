# DNS Shield (Expo + Android DNS-VPN)

اپ با سه حالت: خودکار، گیم، وب‌گردی. هسته: `modules/dns-vpn` (Kotlin، `VpnService`).

## اجرا
```bash
npm install
npx expo install --fix        # هماهنگ‌کردن نسخهٔ پکیج‌ها با SDK
npx expo start                # پیش‌نمایش UI در Expo Go (حالت شبیه‌سازی)
```

## VPN واقعی (Development Build)
```bash
npm i -g eas-cli && eas login
eas build --profile development --platform android   # یا: npx expo run:android
```
بعد از نصب APK: `npx expo start --dev-client`

## گیت‌هاب
```bash
git init && git add . && git commit -m "init"
git branch -M main
git remote add origin https://github.com/USERNAME/dns-shield.git
git push -u origin main
```
برای بیلد خودکار: توی Settings > Secrets مخزن، `EXPO_TOKEN` رو اضافه کن
(توکن از expo.dev > Account settings > Access tokens).

## نکته
اسم پکیج (`com.yourname.dnsshield`) رو توی `app.json` عوض کن.
