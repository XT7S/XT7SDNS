export const C = {
  bg: '#070b14', c1: '#0e1422', c2: '#151c2e', bd: '#1f2740',
  tx: '#f2f4fa', mu: '#7d86a0', red: '#ff2d4a', grn: '#19e68c',
};

// DNS profile per mode
export const MODES = {
  auto: { label: 'خودکار', icon: 'sparkles', dns: ['1.1.1.1', '94.140.14.14'] },
  game: { label: 'گیم', icon: 'game-controller', dns: ['1.1.1.1', '8.8.8.8'] },
  web: { label: 'وب‌گردی', icon: 'globe', dns: ['94.140.14.14', '94.140.15.15'] },
};

// Games used for per-app mode (Android package names). Empty = all apps.
export const GAMES = [
  { name: 'PUBG Mobile', pkg: 'com.tencent.ig' },
  { name: 'Call of Duty', pkg: 'com.activision.callofduty.shooter' },
  { name: 'Free Fire', pkg: 'com.dts.freefireth' },
  { name: 'Mobile Legends', pkg: 'com.mobile.legends' },
];
