// name, flag, base ping (ms), region.
// Later: replace this list with an API call to your own backend.
export const REGIONS = { am: 'آمریکا', eu: 'اروپا', me: 'خاورمیانه', as: 'آسیا' };
export const SERVERS = [
  ['US Central', '🇺🇸', 150, 'am'], ['US East', '🇺🇸', 148, 'am'], ['US West', '🇺🇸', 190, 'am'],
  ['Canada East', '🇨🇦', 155, 'am'], ['Austria', '🇦🇹', 68, 'eu'], ['Belgium', '🇧🇪', 70, 'eu'],
  ['Bulgaria', '🇧🇬', 52, 'eu'], ['Germany', '🇩🇪', 62, 'eu'], ['Netherlands', '🇳🇱', 66, 'eu'],
  ['UK London', '🇬🇧', 74, 'eu'], ['France', '🇫🇷', 70, 'eu'], ['Norway', '🇳🇴', 78, 'eu'],
  ['Turkey', '🇹🇷', 38, 'me'], ['UAE Dubai', '🇦🇪', 44, 'me'], ['Qatar', '🇶🇦', 40, 'me'],
  ['Saudi Arabia', '🇸🇦', 46, 'me'], ['Armenia', '🇦🇲', 36, 'as'], ['India Mumbai', '🇮🇳', 85, 'as'],
  ['Singapore', '🇸🇬', 125, 'as'], ['Japan Tokyo', '🇯🇵', 140, 'as'],
].map(([name, flag, ping, region]) => ({ name, flag, ping, region }));
